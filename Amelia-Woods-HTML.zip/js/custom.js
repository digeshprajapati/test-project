jQuery(document).ready(function () {

    jQuery('.nav-toggle' ).on('click', function (e) {
        jQuery( 'body' ).toggleClass( 'menu-open' );
    });
    
});